class Cell:
    def __init__(self, x: int, y: int):
        """Initialize a cell at (x, y) with all 4 walls present."""
        self.x = x
        self.y = y
        self.visited = False
        self.north = True
        self.south = True
        self.east = True
        self.west = True
        self.is_42 = False
