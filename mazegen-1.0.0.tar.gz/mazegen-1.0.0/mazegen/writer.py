from typing import List, Tuple
from mazegen.cell import Cell


def cell_to_hex(cell: Cell) -> str:
    """Convert a cell's wall configuration to a hexadecimal character."""
    value = 0

    if cell.north:
        value += 1
    if cell.east:
        value += 2
    if cell.south:
        value += 4
    if cell.west:
        value += 8

    return format(value, 'X')


def write_hex_output(maze_grid: List[List[Cell]], entry: Tuple[int, int],
                     exit_pos: Tuple[int, int], solution_path: str,
                     output_file: str) -> None:
    """Write the maze grid and metadata to a file."""

    with open(output_file, "w") as f:
        for row in maze_grid:
            hex_row = ""
            for cell in row:
                hex_row += cell_to_hex(cell)
            f.write(hex_row + "\n")

        f.write("\n")
        f.write(f"{entry[0]},{entry[1]}\n")
        f.write(f"{exit_pos[0]},{exit_pos[1]}\n")
        f.write(f"{solution_path}\n")
